import tarri.datatypes.kata
import tarri.datatypes.angka
import tarri.datatypes.desimal