# file : __init__.py
# lokasi : tarri/src/tarri/keywords/

KEYWORDS = {}

def register(name):
    """Decorator untuk mendaftarkan keyword baru ke registry"""
    def wrapper(func):
        KEYWORDS[name] = func
        return func
    return wrapper

# pastikan import semua keyword agar auto-register
from . import cetak
from . import kondisi
from . import kataAcak