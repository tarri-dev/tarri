# tarri/__init__.py
__version__ = "0.7.7"
