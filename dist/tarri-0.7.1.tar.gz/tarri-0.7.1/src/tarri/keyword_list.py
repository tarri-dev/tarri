# file : keyword_list.py
# lokasi file : tarri/src/tarri/keyword_list.py

import tarri.keywords.cetak
import tarri.keywords.kondisi
import tarri.keywords.kataAcak